# AudioWaveShow

[我的博客](http://blog.csdn.net/qq_25497621/article/details/78623175)


**动态图展示：**


![](https://github.com/T-chuangxin/AudioWaveShow/blob/master/pic_show/aaa.gif)  

![](https://github.com/T-chuangxin/AudioWaveShow/blob/master/pic_show/22.gif)  

